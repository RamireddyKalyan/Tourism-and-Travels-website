Installation Steps(Configuration)
1. Download and Unzip file on your local system.
2.Copy tms folder and tms folder inside root directory (for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

Database Configuration

Open phpmyadmin
Create Database tms
Import database tms.sql (available inside zip package)
Open Your browser put inside browser �http://localhost/tms�

Login Details for admin : 
Open Your browser put inside browser �http://localhost/tms/admin�
Username : admin
Password : Test@123

Login Details for user: 
Open Your browser put inside browser �http://localhost/tms/�
Username : anuj@gmail.com
Password : Test@123